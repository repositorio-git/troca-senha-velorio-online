"""Item de transação (equivalente ao QueueItem / TransactionItem do REFramework)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class Status(str, Enum):
    PENDENTE = "pendente"
    SUCESSO = "sucesso"
    FALHA_NEGOCIO = "falha_negocio"
    FALHA_SISTEMA = "falha_sistema"
    NAO_PROCESSADO = "nao_processado"


@dataclass
class TransactionItem:
    reference: str
    data: Any
    status: Status = Status.PENDENTE
    tentativas: int = 0
    erro: Optional[str] = None
    inicio: Optional[datetime] = None
    fim: Optional[datetime] = None
    # Progresso salvo entre tentativas, para a nova tentativa não refazer o que já deu certo.
    progresso: dict = field(default_factory=dict)
