"""Testes das partes do processo que não dependem do navegador."""

import re
from datetime import datetime

from velorio.framework.config import carregar_config
from velorio.process.log_vo import LogVO
from velorio.process.notificacoes import montar_email_unidade, saudacao
from velorio.process.senhas import gerar_senha, gerar_senhas_distintas, mascarar


def test_senhas():
    for _ in range(500):
        s = gerar_senha(8)
        assert re.fullmatch(r"[1-9]\d{7}", s)
    a, b = gerar_senhas_distintas(2)
    assert a != b
    assert mascarar("86872698") == "86****98"


def test_config_carrega_conforme_documento():
    cfg = carregar_config()
    assert [u.chave for u in cfg.unidades] == [
        "sao_jose", "sao_vicente", "saint_hilaire", "memorial_da_colina", "cristo_rei"]
    sj = cfg.unidades[0]
    assert sj.tipo == "dupla" and [c.post_id for c in sj.cadastros] == [5412, 5659]
    assert "andreia.pires@cortel.com.br" in sj.para and "wagner.molina@cortel.com.br" not in sj.para
    assert all(u.cco == ["david.batista@cortel.com.br", "ti.logs@cortel.com.br"] for u in cfg.unidades)


def test_email_unidade():
    tpl = carregar_config().raiz / "config" / "templates" / "email_unidade.html"
    madrugada = datetime(2026, 11, 16, 4, 0)
    dupla = montar_email_unidade(tpl, [("Capela 1", "11112222"), ("Ecumênica", "33334444")], madrugada)
    assert "Bom dia," in dupla and "Boa tarde" not in dupla
    assert "11112222" in dupla and "33334444" in dupla and "Ecumênica" in dupla
    unica = montar_email_unidade(tpl, [("", "55556666")], madrugada)
    assert "55556666" in unica and "Capela 1" not in unica and "$" not in unica
    assert saudacao(datetime(2026, 1, 1, 15)) == "Boa tarde"


def test_log_vo(tmp_path):
    arq = tmp_path / "Log_VO.txt"
    LogVO(str(arq), mascarar_senhas=True).registrar(
        "São José", datetime(2026, 11, 16, 4, 0, 5), [("Capela 1", "11112222"), ("Capela Ecumênica", "33334444")])
    LogVO(str(arq), mascarar_senhas=False).registrar("Cristo Rei", datetime(2026, 11, 16, 4, 1), [("", "55556666")])
    txt = arq.read_text(encoding="utf-8")
    assert "Senha Capela 1: 11****22" in txt and "Senha: 55556666" in txt
    assert "Data: 16/11/2026 - 04:00:05" in txt
