"""Máquina de estados no estilo REFramework.

    INIT ──► GET TRANSACTION DATA ──► PROCESS TRANSACTION ──┐
     ▲              │ (sem mais itens)        │ sucesso /     │
     │              ▼                         │ negócio       │
     │          END PROCESS ◄─────────────────┘◄──────────────┘
     │                                        │ sistema
     └────────────────────────────────────────┘ (fecha e reabre as aplicações)

Regras (iguais ao REFramework):
- Exceção no INIT é fatal: vai direto para o END.
- BusinessRuleException: a transação falha e segue para a próxima, sem retry.
- Outras exceções (sistema): fecha as aplicações, volta ao INIT e tenta a
  mesma transação de novo, até max_tentativas. Esgotou: falha e segue.
- Muitas exceções de sistema seguidas: encerra o processo.
"""

from __future__ import annotations

import logging
import traceback
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import List, Optional, Protocol

from velorio.framework.exceptions import BusinessRuleException
from velorio.framework.transaction import Status, TransactionItem

log = logging.getLogger("framework")


class Estado(Enum):
    INIT = "Init"
    GET_TRANSACTION = "Get Transaction Data"
    PROCESS = "Process Transaction"
    END = "End Process"


class Processo(Protocol):
    """O que o processo de negócio precisa implementar (os 'workflows' do REFramework)."""

    def init_all_applications(self) -> None: ...
    def close_all_applications(self) -> None: ...
    def kill_all_processes(self) -> None: ...
    def get_transaction_data(self, numero: int) -> Optional[TransactionItem]: ...
    def process_transaction(self, item: TransactionItem) -> None: ...
    def on_transaction_error(self, item: TransactionItem, erro: BaseException) -> None: ...
    def end_process(self, resultado: "Resultado") -> None: ...


@dataclass
class Resultado:
    itens: List[TransactionItem] = field(default_factory=list)
    erro_fatal: Optional[str] = None
    inicio: datetime = field(default_factory=datetime.now)
    fim: Optional[datetime] = None

    @property
    def falhas(self) -> List[TransactionItem]:
        return [i for i in self.itens if i.status != Status.SUCESSO]

    @property
    def sucesso_total(self) -> bool:
        return self.erro_fatal is None and not self.falhas


class REFramework:
    def __init__(self, processo: Processo, max_tentativas: int = 2, max_excecoes_seguidas: int = 3):
        self.processo = processo
        self.max_tentativas = max(1, int(max_tentativas))
        self.max_excecoes_seguidas = max(1, int(max_excecoes_seguidas))

    def executar(self) -> Resultado:
        resultado = Resultado()
        estado = Estado.INIT
        primeira_init = True
        numero = 0
        item: Optional[TransactionItem] = None
        excecoes_seguidas = 0

        while True:
            log.info("── Estado: %s", estado.value)

            if estado is Estado.INIT:
                try:
                    if primeira_init:
                        self.processo.kill_all_processes()
                        primeira_init = False
                    self.processo.init_all_applications()
                    estado = Estado.PROCESS if item is not None else Estado.GET_TRANSACTION
                except Exception as e:  # noqa: BLE001 - qualquer falha no init é fatal
                    resultado.erro_fatal = f"Falha na inicialização: {e}"
                    log.error("%s\n%s", resultado.erro_fatal, traceback.format_exc())
                    estado = Estado.END

            elif estado is Estado.GET_TRANSACTION:
                item = self.processo.get_transaction_data(numero)
                if item is None:
                    estado = Estado.END
                else:
                    resultado.itens.append(item)
                    estado = Estado.PROCESS

            elif estado is Estado.PROCESS:
                assert item is not None
                item.tentativas += 1
                item.inicio = item.inicio or datetime.now()
                log.info("Transação '%s' (tentativa %d/%d)", item.reference, item.tentativas, self.max_tentativas)
                try:
                    self.processo.process_transaction(item)
                    item.status = Status.SUCESSO
                    item.erro = None
                    excecoes_seguidas = 0
                    log.info("Transação '%s': sucesso", item.reference)
                    estado, item, numero = Estado.GET_TRANSACTION, None, numero + 1
                    continue
                except BusinessRuleException as e:
                    item.status, item.erro = Status.FALHA_NEGOCIO, str(e)
                    log.warning("Transação '%s': exceção de negócio: %s", item.reference, e)
                    self._avisar_erro(item, e)
                    excecoes_seguidas = 0
                    estado, item, numero = Estado.GET_TRANSACTION, None, numero + 1
                    continue
                except Exception as e:  # noqa: BLE001 - exceção de sistema
                    item.erro = f"{type(e).__name__}: {e}"
                    log.error("Transação '%s': exceção de sistema: %s\n%s",
                              item.reference, item.erro, traceback.format_exc())
                    self._avisar_erro(item, e)

                # Daqui para baixo: exceção de sistema.
                excecoes_seguidas += 1
                self._fechar_aplicacoes()
                if item.tentativas < self.max_tentativas:
                    log.info("Reiniciando aplicações para nova tentativa de '%s'.", item.reference)
                else:
                    item.status = Status.FALHA_SISTEMA
                    log.error("Transação '%s': tentativas esgotadas.", item.reference)
                    item, numero = None, numero + 1
                if excecoes_seguidas >= self.max_excecoes_seguidas:
                    resultado.erro_fatal = f"{excecoes_seguidas} exceções de sistema seguidas; processo encerrado."
                    log.error(resultado.erro_fatal)
                    estado = Estado.END
                else:
                    estado = Estado.INIT

            elif estado is Estado.END:
                self._fechar_aplicacoes()
                self._marcar_nao_processados(resultado, numero, item)
                resultado.fim = datetime.now()
                try:
                    self.processo.end_process(resultado)
                except Exception:  # noqa: BLE001
                    log.error("Falha no End Process:\n%s", traceback.format_exc())
                return resultado

    # ------------------------------------------------------------------ helpers
    def _fechar_aplicacoes(self) -> None:
        try:
            self.processo.close_all_applications()
        except Exception:  # noqa: BLE001
            log.warning("Falha ao fechar aplicações; matando processos.\n%s", traceback.format_exc())
            try:
                self.processo.kill_all_processes()
            except Exception:  # noqa: BLE001
                log.error("Falha ao matar processos:\n%s", traceback.format_exc())

    def _avisar_erro(self, item: TransactionItem, erro: BaseException) -> None:
        try:
            self.processo.on_transaction_error(item, erro)
        except Exception:  # noqa: BLE001
            log.warning("Falha no tratamento de erro da transação:\n%s", traceback.format_exc())

    def _marcar_nao_processados(self, resultado: Resultado, numero: int, item_atual) -> None:
        """Se o processo parou antes do fim, registra as transações que nem começaram."""
        if item_atual is not None and item_atual.status is Status.PENDENTE:
            item_atual.status = Status.FALHA_SISTEMA
        if resultado.erro_fatal is None:
            return
        n = numero + (1 if item_atual is not None else 0)
        while True:
            restante = self.processo.get_transaction_data(n)
            if restante is None:
                break
            if restante not in resultado.itens:
                restante.status = Status.NAO_PROCESSADO
                restante.erro = "Não processado: o processo foi encerrado antes."
                resultado.itens.append(restante)
            n += 1
