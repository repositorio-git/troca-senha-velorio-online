"""Montagem dos e-mails: comunicado da unidade e alerta para a TI."""

from __future__ import annotations

import html
from datetime import datetime
from pathlib import Path
from string import Template
from typing import List, Optional, Tuple

CARD = """        <!-- Card $comentario -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0"
          style="margin-bottom:$margem; border-collapse:collapse;">
          <tr>
            <td style="border:1px solid #e5e7eb; padding:22px; background:#f9fafb;">
$rotulo              <p style="margin:0; font-size:30px; font-weight:700; color:#042554;
                         letter-spacing:3px; text-align:center;
                         font-family:'Ubuntu', Arial, sans-serif;">
                $senha
              </p>
            </td>
          </tr>
        </table>
"""

ROTULO = """              <p style="margin:0 0 8px 0; font-size:13px; color:#6b7280;
                         text-transform:uppercase; letter-spacing:0.8px;
                         font-family:'Ubuntu', Arial, sans-serif;">
                $texto
              </p>
"""


def saudacao(agora: Optional[datetime] = None) -> str:
    hora = (agora or datetime.now()).hour
    if 5 <= hora < 12:
        return "Bom dia"
    if 12 <= hora < 18:
        return "Boa tarde"
    return "Boa noite" if hora >= 18 else "Bom dia"


def montar_email_unidade(template: Path, senhas: List[Tuple[str, str]], agora: Optional[datetime] = None) -> str:
    """senhas: lista de (rótulo, senha). Capela única = um card sem rótulo (como no original)."""
    cards = []
    for i, (rotulo, senha) in enumerate(senhas):
        ultimo = i == len(senhas) - 1
        cards.append(
            Template(CARD).substitute(
                comentario=rotulo or "Capela",
                margem="30px" if ultimo and len(senhas) > 1 else "18px",
                rotulo=Template(ROTULO).substitute(texto=html.escape(rotulo)) if rotulo else "",
                senha=html.escape(senha),
            )
        )
    corpo = Template(template.read_text(encoding="utf-8"))
    return corpo.substitute(saudacao=saudacao(agora), cards="\n".join(cards).rstrip("\n"))


def montar_alerta_ti(linhas_unidades: List[Tuple[str, str, str]], erro_fatal: Optional[str],
                     avisos: List[str], arquivo_log: Optional[Path]) -> str:
    """linhas_unidades: (unidade, situação, detalhe)."""
    cores = {"OK": "#166534", "FALHA": "#b91c1c", "NÃO PROCESSADO": "#92400e"}
    linhas = "".join(
        f"<tr><td style='padding:6px 10px;border:1px solid #ddd'>{html.escape(u)}</td>"
        f"<td style='padding:6px 10px;border:1px solid #ddd;color:{cores.get(s, '#000')};font-weight:bold'>{html.escape(s)}</td>"
        f"<td style='padding:6px 10px;border:1px solid #ddd'>{html.escape(d)}</td></tr>"
        for u, s, d in linhas_unidades
    )
    partes = [
        "<div style='font-family:Arial,sans-serif;font-size:14px;color:#1f2937'>",
        "<p>Resultado da troca semanal de senhas do Velório Online:</p>",
    ]
    if erro_fatal:
        partes.append(f"<p style='color:#b91c1c'><b>Erro fatal:</b> {html.escape(erro_fatal)}</p>")
    partes.append(
        "<table style='border-collapse:collapse'><tr>"
        "<th style='padding:6px 10px;border:1px solid #ddd;text-align:left'>Unidade</th>"
        "<th style='padding:6px 10px;border:1px solid #ddd;text-align:left'>Situação</th>"
        "<th style='padding:6px 10px;border:1px solid #ddd;text-align:left'>Detalhe</th></tr>"
        f"{linhas}</table>"
    )
    if avisos:
        partes.append("<p><b>Avisos:</b></p><ul>" + "".join(f"<li>{html.escape(a)}</li>" for a in avisos) + "</ul>")
    partes.append(
        "<p>Para as unidades com falha, siga a execução manual da Documentação de Negócio (seção 5.2). "
        "Se o detalhe disser que a senha nova já foi gravada, ela pode ser consultada no próprio cadastro do WordPress.</p>"
    )
    if arquivo_log:
        partes.append(f"<p style='color:#6b7280'>Log da execução: {html.escape(str(arquivo_log))}</p>")
    partes.append("</div>")
    return "\n".join(partes)
