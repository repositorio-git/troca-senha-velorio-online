"""Ponto de entrada: troca semanal das senhas do Velório Online.

Uso:
    python main.py                          # execução normal (segunda-feira, 04h)
    python main.py --dry-run                # só faz login e lê os cadastros; não grava nem envia nada
    python main.py --somente sao_vicente    # roda só a(s) unidade(s) indicada(s)
    python main.py --redirecionar-emails voce@cortel.com.br
                                            # GRAVA as senhas, mas manda todos os e-mails para um endereço só

Códigos de saída (para o Agendador de Tarefas):
    0 = tudo certo | 1 = alguma unidade falhou | 2 = erro fatal (não iniciou ou parou no meio)
"""

from __future__ import annotations

import argparse
import logging
import sys

from velorio.framework.config import carregar_config
from velorio.framework.exceptions import ConfigError
from velorio.framework.logging_setup import configurar_logging
from velorio.framework.state_machine import REFramework
from velorio.process.processo import ProcessoVelorioOnline


def main() -> int:
    parser = argparse.ArgumentParser(description="Troca semanal de senhas do Velório Online")
    parser.add_argument("--dry-run", action="store_true", help="Não grava senhas nem envia e-mails.")
    parser.add_argument("--somente", nargs="+", metavar="CHAVE", help="Chaves das unidades (ver config.yaml).")
    parser.add_argument("--redirecionar-emails", metavar="EMAIL", help="Envia todos os e-mails para este endereço.")
    parser.add_argument("--mostrar-navegador", action="store_true", help="Desliga o modo headless.")
    args = parser.parse_args()

    try:
        cfg = carregar_config()
    except (ConfigError, OSError) as e:
        print(f"Erro de configuração: {e}", file=sys.stderr)
        return 2

    arquivo_log = configurar_logging(cfg.raiz / "logs")
    log = logging.getLogger("main")
    if args.mostrar_navegador:
        cfg.raw["wordpress"]["headless"] = False

    log.info("Início da troca de senhas do Velório Online%s.", " (DRY-RUN)" if args.dry_run else "")
    try:
        processo = ProcessoVelorioOnline(
            cfg,
            somente=args.somente,
            dry_run=args.dry_run,
            redirecionar_emails=args.redirecionar_emails,
            arquivo_log=arquivo_log,
        )
    except ConfigError as e:
        log.error("Erro de configuração: %s", e)
        return 2

    framework = REFramework(
        processo,
        max_tentativas=cfg.get("framework.max_tentativas", 2),
        max_excecoes_seguidas=cfg.get("framework.max_excecoes_sistema_seguidas", 3),
    )
    resultado = framework.executar()

    if resultado.erro_fatal:
        return 2
    return 1 if resultado.falhas else 0


if __name__ == "__main__":
    sys.exit(main())
