"""Tipos de exceção do framework.

Como no REFramework:
- BusinessRuleException: problema de dado/regra. Não adianta tentar de novo,
  a transação falha direto.
- Qualquer outra exceção é tratada como exceção de sistema: o framework fecha
  e reabre as aplicações e tenta a transação de novo (até max_tentativas).
"""


class BusinessRuleException(Exception):
    """Falha de regra de negócio: a transação não é repetida."""


class ConfigError(Exception):
    """Configuração ou credencial ausente/inválida."""
