"""Carga de configuração (equivalente ao InitAllSettings do REFramework).

- config/config.yaml: settings e constantes do processo.
- .env (ou variáveis de ambiente do Windows): credenciais ("Assets").
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import yaml
from dotenv import load_dotenv

from velorio.framework.exceptions import ConfigError

RAIZ_PROJETO = Path(__file__).resolve().parents[2]


@dataclass(frozen=True)
class Cadastro:
    post_id: int
    nome: str


@dataclass(frozen=True)
class Unidade:
    chave: str
    nome: str
    tipo: str  # "unica" | "dupla"
    cadastros: List[Cadastro]
    para: List[str]
    cco: List[str]


@dataclass
class Config:
    raw: dict
    unidades: List[Unidade]
    raiz: Path

    def get(self, caminho: str, padrao=None):
        """Acesso por caminho pontuado: cfg.get('wordpress.timeout_segundos')."""
        atual = self.raw
        for parte in caminho.split("."):
            if not isinstance(atual, dict) or parte not in atual:
                return padrao
            atual = atual[parte]
        return atual

    @staticmethod
    def segredo(nome: str, obrigatorio: bool = True) -> Optional[str]:
        valor = os.environ.get(nome)
        if obrigatorio and not valor:
            raise ConfigError(
                f"Credencial '{nome}' não encontrada. Defina no arquivo .env ou nas variáveis de ambiente."
            )
        return valor


def carregar_config(caminho: Optional[Path] = None) -> Config:
    load_dotenv(RAIZ_PROJETO / ".env")
    caminho = caminho or RAIZ_PROJETO / "config" / "config.yaml"
    with open(caminho, encoding="utf-8") as f:
        raw = yaml.safe_load(f)

    unidades = []
    chaves = set()
    for u in raw.get("unidades", []):
        if u["tipo"] not in ("unica", "dupla"):
            raise ConfigError(f"Unidade {u['chave']}: tipo deve ser 'unica' ou 'dupla'.")
        if u["chave"] in chaves:
            raise ConfigError(f"Chave de unidade repetida: {u['chave']}")
        if not u.get("cadastros") or not u.get("para"):
            raise ConfigError(f"Unidade {u['chave']}: precisa de cadastros e destinatários.")
        chaves.add(u["chave"])
        unidades.append(
            Unidade(
                chave=u["chave"],
                nome=u["nome"],
                tipo=u["tipo"],
                cadastros=[Cadastro(int(c["post_id"]), c["nome"]) for c in u["cadastros"]],
                para=list(u["para"]),
                cco=list(u.get("cco") or []),
            )
        )
    if not unidades:
        raise ConfigError("Nenhuma unidade configurada.")
    return Config(raw=raw, unidades=unidades, raiz=RAIZ_PROJETO)
