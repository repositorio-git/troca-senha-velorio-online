"""Registro no Log_VO.txt da rede (mesmo formato do Rocketbot)."""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import List, Tuple

from velorio.process.senhas import mascarar

log = logging.getLogger("log_vo")

SEPARADOR = "-" * 57


class LogVO:
    def __init__(self, caminho: str, mascarar_senhas: bool = True):
        self.caminho = Path(caminho)
        self.mascarar_senhas = mascarar_senhas

    def registrar(self, empreendimento: str, quando: datetime, senhas: List[Tuple[str, str]]) -> None:
        """senhas: lista de (rótulo, senha). Rótulo vazio = capela única."""
        linhas = [f"Empreendimento: {empreendimento}", f"Data: {quando:%d/%m/%Y - %H:%M:%S}"]
        for rotulo, senha in senhas:
            valor = mascarar(senha) if self.mascarar_senhas else senha
            linhas.append(f"Senha {rotulo}: {valor}" if rotulo else f"Senha: {valor}")
        linhas.append(SEPARADOR)
        with open(self.caminho, "a", encoding="utf-8") as f:
            f.write("\n".join(linhas) + "\n")
        log.info("Registro gravado no Log_VO: %s", empreendimento)
