"""Log da execução: console + arquivo diário em logs/."""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path


def configurar_logging(pasta_logs: Path) -> Path:
    pasta_logs.mkdir(parents=True, exist_ok=True)
    arquivo = pasta_logs / f"execucao_{datetime.now():%Y%m%d_%H%M%S}.log"

    formato = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    raiz = logging.getLogger()
    raiz.setLevel(logging.INFO)
    raiz.handlers.clear()

    console = logging.StreamHandler()
    console.setFormatter(formato)
    raiz.addHandler(console)

    em_arquivo = logging.FileHandler(arquivo, encoding="utf-8")
    em_arquivo.setFormatter(formato)
    raiz.addHandler(em_arquivo)

    # Selenium e urllib3 são verborrágicos demais no INFO.
    for barulhento in ("selenium", "urllib3", "WDM"):
        logging.getLogger(barulhento).setLevel(logging.WARNING)
    return arquivo
