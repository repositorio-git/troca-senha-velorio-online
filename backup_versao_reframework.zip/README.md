# Troca de Senha — Velório Online

Migração do processo **VELORIO_ONLINE** (Rocketbot: Master / Login_WordPress / Altera_Senha) para Python,
organizado no padrão **REFramework**.

Toda segunda-feira às 04h: gera senhas numéricas de 8 dígitos, grava nos cadastros de Empreendimentos do
WordPress da Cortel, confere se ficaram salvas, registra no `Log_VO.txt` e envia o e-mail "Velório Online"
para cada unidade. Se algo falhar, a TI recebe um alerta.

## Estrutura

```
troca-senha-velorio-online/
├── main.py                        # ponto de entrada (CLI)
├── config/
│   ├── config.yaml                # settings, unidades, destinatários   (≈ Config.xlsx)
│   └── templates/email_unidade.html
├── .env.example                   # credenciais                         (≈ Assets do Orchestrator)
├── velorio/
│   ├── framework/                 # o "REFramework" em si, genérico
│   │   ├── state_machine.py       # Init → Get Transaction → Process → End
│   │   ├── transaction.py         # TransactionItem + status
│   │   ├── exceptions.py          # BusinessRuleException
│   │   ├── config.py              # InitAllSettings
│   │   └── logging_setup.py
│   ├── apps/                      # aplicações automatizadas
│   │   ├── wordpress.py           # robôs Login_WordPress + Altera_Senha
│   │   └── mailer.py              # Office 365 (SMTP ou Graph)
│   └── process/                   # regras de negócio deste processo
│       ├── processo.py            # robô Master, nos hooks do REFramework
│       ├── senhas.py
│       ├── notificacoes.py
│       └── log_vo.py
└── tests/
```

## REFramework, versão Python

| REFramework (UiPath)        | Aqui                                                             |
|-----------------------------|------------------------------------------------------------------|
| InitAllSettings             | `carregar_config()`: `config.yaml` + `.env`                      |
| KillAllProcesses            | `kill_all_processes()`: fecha o Chrome                           |
| InitAllApplications         | `init_all_applications()`: abre o Chrome e faz login no WP       |
| GetTransactionData          | uma transação por **unidade** (5): São José cobre 2 cadastros    |
| Process                     | grava, salva, confere, registra no Log_VO e envia o e-mail       |
| SetTransactionStatus        | dentro da `state_machine.py`                                      |
| CloseAllApplications        | `close_all_applications()`                                       |
| End Process                 | resumo no log + alerta para a TI se houve falha                  |

Regras de exceção:

- **BusinessRuleException** (ex.: o cadastro não tem o campo de senha esperado): a unidade falha sem nova tentativa.
- **Exceção de sistema** (timeout, página não carregou, WordPress não confirmou o salvamento): fecha o Chrome,
  faz login de novo e tenta a mesma unidade outra vez (`framework.max_tentativas`).
- **Falha no Init** (login recusado, credencial ausente): nada é processado, a TI é avisada.

As senhas de cada unidade são geradas **uma vez no início** e ficam no item da transação. Numa nova tentativa,
o processo usa as mesmas senhas e pula os cadastros já salvos e conferidos, então o Crematório Metropolitano e o
São José nunca ficam com senhas diferentes e nenhuma unidade recebe dois e-mails.

## O que mudou em relação ao Rocketbot

- Abre o cadastro direto pela URL (`post.php?post=<ID>&action=edit`), com os mesmos IDs que o robô clicava na listagem.
- O "clica no nome, Tab, Delete, clica na senha" virou "limpa o campo de senha e digita", nos mesmos IDs do ACF.
- Os 17 Tabs + dois cliques no `#publish` viraram um clique em **Atualizar** + espera pela mensagem de sucesso.
- Depois de salvar, relê os campos e confere: **o e-mail só sai se a senha ficou gravada**.
- Esperas fixas viraram esperas por elemento.
- Senhas geradas com gerador criptográfico (`secrets`).
- Saudação conforme o horário ("Bom dia" às 04h).
- Destinatários conforme a Documentação de Negócio, seção 3.6.
- `Log_VO.txt` grava as senhas mascaradas (`86****98`). Para voltar ao formato antigo: `log_vo.mascarar_senhas: false`.
- Credenciais fora do código, no `.env`.

## Instalação (Windows)

```cmd
cd C:\codes\PycharmProjects\troca-senha-velorio-online
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
copy .env.example .env
notepad .env
```

Precisa do Google Chrome instalado. O Selenium baixa o chromedriver certo sozinho na primeira execução
(requer acesso à internet).

## Execução

```cmd
.venv\Scripts\python main.py --dry-run --mostrar-navegador
```

Faz login e abre cada cadastro, mostrando no log as senhas atuais mascaradas. **Não grava nada e não envia e-mail.**
É o primeiro teste a fazer.

```cmd
.venv\Scripts\python main.py --somente sao_vicente --redirecionar-emails seu.email@cortel.com.br
```

**Grava de verdade** a senha da unidade escolhida, mas manda o e-mail só para você. Atenção: a unidade não fica
sabendo da senha nova, então repasse a ela ou rode a unidade de novo sem o redirecionamento.

```cmd
.venv\Scripts\python main.py
```

Execução normal. Códigos de saída: `0` tudo certo, `1` alguma unidade falhou, `2` erro fatal.

Logs em `logs\` e screenshots de erro em `logs\screenshots\`.

## Agendamento (segunda-feira, 04h)

```cmd
schtasks /Create /TN "Velorio Online - Troca de Senhas" /SC WEEKLY /D MON /ST 04:00 ^
  /TR "\"C:\codes\PycharmProjects\troca-senha-velorio-online\.venv\Scripts\python.exe\" \"C:\codes\PycharmProjects\troca-senha-velorio-online\main.py\"" ^
  /RU <USUARIO_DO_SERVIDOR> /RP
```

Use um usuário com acesso ao `\\dcsrv01\Deptos\...` (para o Log_VO). Desative o agendamento do Rocketbot antes
de ativar este, senão as unidades recebem dois e-mails com senhas diferentes.

## E-mail: SMTP ou Graph

O padrão é `email.backend: smtp`, com a conta `cortex@cortel.com.br` e a senha em `EMAIL_SENHA`, como o Rocketbot.
Se o SMTP AUTH estiver desativado no tenant do Microsoft 365, troque para `graph` e preencha `GRAPH_*` no `.env`
(app registration no Entra ID com a permissão de aplicação `Mail.Send`).

## Testes

```cmd
.venv\Scripts\pip install -r requirements-dev.txt
.venv\Scripts\python -m pytest
```

Cobrem a máquina de estados, as regras de negócio, o template de e-mail, o Log_VO, o envio SMTP e o fluxo
completo com WordPress falso (incluindo retry no meio do São José).
