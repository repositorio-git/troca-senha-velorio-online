"""Geração das senhas das capelas."""

from __future__ import annotations

import secrets
from typing import List


def gerar_senha(digitos: int = 8) -> str:
    """Senha numérica de N dígitos, sem zero à esquerda (como o random.randint do Rocketbot),
    mas com gerador criptográfico."""
    minimo = 10 ** (digitos - 1)
    return str(minimo + secrets.randbelow(9 * minimo))


def gerar_senhas_distintas(quantidade: int, digitos: int = 8) -> List[str]:
    senhas: List[str] = []
    while len(senhas) < quantidade:
        s = gerar_senha(digitos)
        if s not in senhas:
            senhas.append(s)
    return senhas


def mascarar(senha: str) -> str:
    if len(senha) <= 4:
        return "*" * len(senha)
    return senha[:2] + "*" * (len(senha) - 4) + senha[-2:]
