"""Estrutura no estilo REFramework: Init -> Get Transaction Data -> Process -> End."""
