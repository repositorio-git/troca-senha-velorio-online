"""Testes da máquina de estados (sem navegador)."""

from velorio.framework.exceptions import BusinessRuleException
from velorio.framework.state_machine import REFramework
from velorio.framework.transaction import Status, TransactionItem


class Falso:
    def __init__(self, comportamentos, falha_init_em=None):
        self.itens = [TransactionItem(reference=f"t{i}", data=c) for i, c in enumerate(comportamentos)]
        self.inits = 0
        self.falha_init_em = falha_init_em or set()
        self.resultado = None

    def kill_all_processes(self): pass
    def close_all_applications(self): pass
    def on_transaction_error(self, item, erro): pass

    def init_all_applications(self):
        self.inits += 1
        if self.inits in self.falha_init_em:
            raise RuntimeError("login falhou")

    def get_transaction_data(self, n):
        return self.itens[n] if n < len(self.itens) else None

    def process_transaction(self, item):
        acao = item.data.pop(0) if item.data else "ok"
        if acao == "sistema":
            raise RuntimeError("timeout")
        if acao == "negocio":
            raise BusinessRuleException("regra")

    def end_process(self, resultado):
        self.resultado = resultado


def test_tudo_ok():
    p = Falso([["ok"], ["ok"]])
    r = REFramework(p).executar()
    assert r.sucesso_total and p.inits == 1


def test_retry_de_sistema_reinicia_aplicacoes():
    p = Falso([["sistema", "ok"], ["ok"]])
    r = REFramework(p, max_tentativas=2).executar()
    assert [i.status for i in r.itens] == [Status.SUCESSO, Status.SUCESSO]
    assert r.itens[0].tentativas == 2 and p.inits == 2


def test_negocio_nao_repete():
    p = Falso([["negocio"], ["ok"]])
    r = REFramework(p).executar()
    assert r.itens[0].status is Status.FALHA_NEGOCIO and r.itens[0].tentativas == 1
    assert r.itens[1].status is Status.SUCESSO


def test_tentativas_esgotadas_segue_para_proxima():
    p = Falso([["sistema", "sistema"], ["ok"]])
    r = REFramework(p, max_tentativas=2, max_excecoes_seguidas=5).executar()
    assert r.itens[0].status is Status.FALHA_SISTEMA and r.itens[1].status is Status.SUCESSO


def test_init_falho_marca_todos_nao_processados():
    p = Falso([["ok"], ["ok"]], falha_init_em={1})
    r = REFramework(p).executar()
    assert r.erro_fatal and [i.status for i in r.itens] == [Status.NAO_PROCESSADO] * 2


def test_excecoes_seguidas_encerram():
    p = Falso([["sistema"] * 5, ["ok"], ["ok"]])
    r = REFramework(p, max_tentativas=5, max_excecoes_seguidas=2).executar()
    assert r.erro_fatal
    assert [i.status for i in r.itens] == [Status.FALHA_SISTEMA, Status.NAO_PROCESSADO, Status.NAO_PROCESSADO]
