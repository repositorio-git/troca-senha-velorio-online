"""Automação do painel WordPress (cadastro de Empreendimentos).

Tradução dos robôs VELORIO_ONLINE_Login_WordPress e VELORIO_ONLINE_Altera_Senha.
Mesmos seletores do Rocketbot (#user_login, #user_pass, #wp-submit, #publish e
os IDs dos campos do ACF), mas trocando esperas fixas e sequências de teclas por
esperas por elemento e confirmação de salvamento.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from selenium import webdriver
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from velorio.framework.exceptions import BusinessRuleException

log = logging.getLogger("wordpress")


class LoginError(Exception):
    """Login recusado pelo WordPress (usuário ou senha errados, conta bloqueada...)."""


class WordPressAdmin:
    def __init__(
        self,
        base_url: str,
        acf_repeater: str,
        acf_campo_senha: str,
        headless: bool = True,
        timeout: int = 30,
        pasta_screenshots: Optional[Path] = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.acf_repeater = acf_repeater
        self.acf_campo_senha = acf_campo_senha
        self.headless = headless
        self.timeout = timeout
        self.pasta_screenshots = pasta_screenshots
        self.driver: Optional[WebDriver] = None

    # ------------------------------------------------------------ navegador
    def iniciar(self) -> None:
        opcoes = webdriver.ChromeOptions()
        if self.headless:
            opcoes.add_argument("--headless=new")
        opcoes.add_argument("--window-size=1600,1000")
        opcoes.add_argument("--disable-gpu")
        opcoes.add_argument("--no-first-run")
        # Aceita o "Sair do site? As alterações podem não ser salvas" do WordPress.
        opcoes.set_capability("unhandledPromptBehavior", "accept")
        self.driver = webdriver.Chrome(options=opcoes)
        self.driver.set_page_load_timeout(self.timeout * 2)
        log.info("Navegador iniciado (headless=%s).", self.headless)

    def fechar(self) -> None:
        if self.driver is not None:
            try:
                self.driver.quit()
            finally:
                self.driver = None
                log.info("Navegador encerrado.")

    @property
    def _d(self) -> WebDriver:
        if self.driver is None:
            raise WebDriverException("Navegador não iniciado.")
        return self.driver

    def _esperar(self, timeout: Optional[int] = None) -> WebDriverWait:
        return WebDriverWait(self._d, timeout or self.timeout)

    def screenshot(self, nome: str) -> Optional[Path]:
        if self.driver is None or self.pasta_screenshots is None:
            return None
        try:
            self.pasta_screenshots.mkdir(parents=True, exist_ok=True)
            arquivo = self.pasta_screenshots / f"{datetime.now():%Y%m%d_%H%M%S}_{nome}.png"
            self.driver.save_screenshot(str(arquivo))
            log.info("Screenshot salvo: %s", arquivo)
            return arquivo
        except WebDriverException:
            log.warning("Não foi possível salvar o screenshot.")
            return None

    # ---------------------------------------------------------------- login
    def login(self, usuario: str, senha: str) -> None:
        """Robô Login_WordPress: abre a listagem de Empreendimentos e faz login."""
        self._d.get(f"{self.base_url}/wp-admin/edit.php?post_type=empreendimentos")
        self._esperar().until(
            EC.any_of(
                EC.presence_of_element_located((By.ID, "user_login")),
                EC.presence_of_element_located((By.ID, "wpadminbar")),
            )
        )
        if self._d.find_elements(By.ID, "wpadminbar"):
            log.info("Sessão já ativa no WordPress.")
            return

        self._digitar(self._d.find_element(By.ID, "user_login"), usuario)
        self._digitar(self._d.find_element(By.ID, "user_pass"), senha)
        self._d.find_element(By.ID, "wp-submit").click()

        self._esperar().until(
            EC.any_of(
                EC.presence_of_element_located((By.ID, "wpadminbar")),
                EC.presence_of_element_located((By.ID, "login_error")),
            )
        )
        erros = self._d.find_elements(By.ID, "login_error")
        if erros:
            raise LoginError(f"WordPress recusou o login: {erros[0].text.strip()}")
        log.info("Login no WordPress realizado.")

    # ------------------------------------------------------------- cadastro
    def abrir_cadastro(self, post_id: int) -> str:
        """Abre a tela de edição do empreendimento. Retorna o título do cadastro."""
        self._d.get(f"{self.base_url}/wp-admin/post.php?post={post_id}&action=edit")
        try:
            self._esperar().until(EC.element_to_be_clickable((By.ID, "publish")))
        except TimeoutException:
            if self._d.find_elements(By.ID, "user_login"):
                raise WebDriverException("Sessão do WordPress expirou (voltou para a tela de login).")
            raise
        titulo = self._d.find_element(By.ID, "title").get_attribute("value") or ""
        log.info("Cadastro %s aberto: %s", post_id, titulo)
        return titulo

    def _id_campo_senha(self, linha: int) -> str:
        return f"acf-{self.acf_repeater}-row-{linha}-{self.acf_campo_senha}"

    def _campo_senha(self, linha: int):
        try:
            return self._esperar(10).until(
                EC.presence_of_element_located((By.ID, self._id_campo_senha(linha)))
            )
        except TimeoutException:
            raise BusinessRuleException(
                f"Campo de senha da capela (linha {linha}) não existe no cadastro. "
                "O cadastro pode ter menos capelas do que o configurado ou o layout do ACF mudou."
            ) from None

    def ler_senha(self, linha: int) -> str:
        return (self._campo_senha(linha).get_attribute("value") or "").strip()

    def preencher_senha(self, linha: int, senha: str) -> None:
        """Substitui o 'clica no nome, Tab, Delete, clica na senha, digita' do Rocketbot."""
        campo = self._campo_senha(linha)
        self._d.execute_script("arguments[0].scrollIntoView({block: 'center'});", campo)
        self._digitar(campo, senha)
        if (campo.get_attribute("value") or "").strip() != senha:
            raise WebDriverException(f"Campo da linha {linha} não aceitou a senha digitada.")

    def salvar(self) -> None:
        """Clica em Atualizar e espera a mensagem de sucesso do WordPress."""
        botao = self._d.find_element(By.ID, "publish")
        self._d.execute_script("arguments[0].scrollIntoView({block: 'center'});", botao)
        try:
            botao.click()
        except WebDriverException:
            self._d.execute_script("arguments[0].click();", botao)

        self._esperar().until(EC.staleness_of(botao))
        try:
            self._esperar().until(
                EC.presence_of_element_located(
                    (By.CSS_SELECTOR, "#message.notice-success, #message.updated")
                )
            )
        except TimeoutException:
            raise WebDriverException(
                "O WordPress não confirmou o salvamento (mensagem de 'atualizado' não apareceu)."
            ) from None
        log.info("Cadastro salvo.")

    # ---------------------------------------------------------------- util
    def _digitar(self, campo, texto: str) -> None:
        campo.click()
        campo.send_keys(Keys.CONTROL, "a")
        campo.send_keys(Keys.DELETE)
        campo.send_keys(texto)
