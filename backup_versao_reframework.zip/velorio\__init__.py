"""Troca semanal de senhas do Velório Online (migração do Rocketbot)."""
