"""Fluxo completo com WordPress e e-mail falsos: retry, idempotência e alerta."""

from velorio.framework.config import carregar_config
from velorio.framework.state_machine import REFramework
from velorio.framework.transaction import Status
from velorio.process.processo import ProcessoVelorioOnline


class WPFalso:
    def __init__(self, falhar_salvar_em=None):
        self.senhas = {}  # post_id -> {linha: senha}
        self.aberto = None
        self.rascunho = {}
        self.falhar_salvar_em = set(falhar_salvar_em or [])
        self.salvamentos = []

    def iniciar(self): pass
    def fechar(self): pass
    def login(self, u, s): pass
    def screenshot(self, nome): pass

    def abrir_cadastro(self, post_id):
        self.aberto, self.rascunho = post_id, dict(self.senhas.get(post_id, {}))
        return str(post_id)

    def ler_senha(self, linha):
        return self.senhas.get(self.aberto, {}).get(linha, "")

    def preencher_senha(self, linha, senha):
        self.rascunho[linha] = senha

    def salvar(self):
        if self.aberto in self.falhar_salvar_em:
            self.falhar_salvar_em.discard(self.aberto)
            raise RuntimeError("timeout ao salvar")
        self.senhas[self.aberto] = dict(self.rascunho)
        self.salvamentos.append(self.aberto)


class MailFalso:
    def __init__(self):
        self.enviados = []

    def enviar(self, para, assunto, html, cco=None):
        self.enviados.append((tuple(para), assunto, html))


def montar(monkeypatch, tmp_path, wp):
    monkeypatch.setenv("WP_USUARIO", "u")
    monkeypatch.setenv("WP_SENHA", "s")
    monkeypatch.setenv("EMAIL_SENHA", "x")
    cfg = carregar_config()
    cfg.raw["log_vo"]["caminho"] = str(tmp_path / "Log_VO.txt")
    p = ProcessoVelorioOnline(cfg)
    p.log_vo.caminho = tmp_path / "Log_VO.txt"
    p.wp, p.mailer = wp, MailFalso()
    return p


def test_retry_nao_regrava_cadastro_ja_salvo(monkeypatch, tmp_path):
    wp = WPFalso(falhar_salvar_em={5659})  # São José falha na 1a vez, depois do Crematório já salvo
    p = montar(monkeypatch, tmp_path, wp)
    r = REFramework(p, max_tentativas=2).executar()
    assert r.sucesso_total
    assert wp.salvamentos.count(5412) == 1 and wp.salvamentos.count(5659) == 1
    # Crematório e São José com as MESMAS duas senhas
    assert wp.senhas[5412] == wp.senhas[5659] and wp.senhas[5412][0] != wp.senhas[5412][1]
    assert len(p.mailer.enviados) == 5  # um por unidade, nenhum alerta


def test_falha_definitiva_gera_alerta(monkeypatch, tmp_path):
    wp = WPFalso()
    p = montar(monkeypatch, tmp_path, wp)
    original = wp.salvar

    def sempre_falha_cristo_rei():
        if wp.aberto == 5650:
            raise RuntimeError("timeout")
        original()
    wp.salvar = sempre_falha_cristo_rei

    r = REFramework(p, max_tentativas=2, max_excecoes_seguidas=5).executar()
    assert r.itens[-1].status is Status.FALHA_SISTEMA
    enviados = p.mailer.enviados
    assert len(enviados) == 5  # 4 unidades + 1 alerta
    para, assunto, html = enviados[-1]
    assert para == ("ti.logs@cortel.com.br",) and assunto.startswith("[FALHA]") and "Cristo Rei" in html
    assert "atendimento.cristorei@cortel.com.br" not in [e for env in enviados for e in env[0]]
