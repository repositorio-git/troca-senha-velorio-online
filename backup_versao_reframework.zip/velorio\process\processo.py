"""Processo de negócio: troca semanal das senhas do Velório Online.

Tradução do robô VELORIO_ONLINE_Master para os 'workflows' do REFramework:
- Init:            login no WordPress (robô Login_WordPress).
- Get Transaction: uma transação por unidade (5 no total; São José cobre 2 cadastros).
- Process:         grava as senhas em cada cadastro (robô Altera_Senha), confere o
                   salvamento, registra no Log_VO e manda o e-mail da unidade.
- End:             resumo e alerta para a TI se algo falhou.

As senhas de cada unidade são geradas UMA vez, antes de tudo, e ficam no item da
transação. Assim, se uma tentativa falhar no meio, a nova tentativa grava as
mesmas senhas e pula o que já foi salvo e conferido.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from velorio.apps.mailer import GraphMailer, Mailer, RedirecionadorMailer, SmtpMailer
from velorio.apps.wordpress import WordPressAdmin
from velorio.framework.config import Config, Unidade
from velorio.framework.exceptions import ConfigError
from velorio.framework.state_machine import Resultado
from velorio.framework.transaction import Status, TransactionItem
from velorio.process.log_vo import LogVO
from velorio.process.notificacoes import montar_alerta_ti, montar_email_unidade
from velorio.process.senhas import gerar_senhas_distintas, mascarar

log = logging.getLogger("processo")

ROTULOS_DUPLA = ("Capela 1", "Ecumênica")


class ProcessoVelorioOnline:
    def __init__(
        self,
        cfg: Config,
        somente: Optional[List[str]] = None,
        dry_run: bool = False,
        redirecionar_emails: Optional[str] = None,
        arquivo_log: Optional[Path] = None,
    ):
        self.cfg = cfg
        self.dry_run = dry_run
        self.arquivo_log = arquivo_log
        self.avisos: List[str] = []
        self.data_execucao = datetime.now()

        unidades = cfg.unidades
        if somente:
            desconhecidas = set(somente) - {u.chave for u in unidades}
            if desconhecidas:
                raise ConfigError(f"Unidade(s) desconhecida(s): {', '.join(sorted(desconhecidas))}")
            unidades = [u for u in unidades if u.chave in somente]

        digitos = int(cfg.get("senhas.digitos", 8))
        self.itens: List[TransactionItem] = []
        for u in unidades:
            qtd = 2 if u.tipo == "dupla" else 1
            novas = gerar_senhas_distintas(qtd, digitos)
            rotulos = ROTULOS_DUPLA if u.tipo == "dupla" else ("",)
            self.itens.append(
                TransactionItem(reference=u.nome, data={"unidade": u, "senhas": list(zip(rotulos, novas))})
            )

        self.wp = WordPressAdmin(
            base_url=cfg.get("wordpress.base_url"),
            acf_repeater=cfg.get("wordpress.acf.repeater"),
            acf_campo_senha=cfg.get("wordpress.acf.campo_senha"),
            headless=bool(cfg.get("wordpress.headless", True)),
            timeout=int(cfg.get("wordpress.timeout_segundos", 30)),
            pasta_screenshots=cfg.raiz / "logs" / "screenshots",
        )
        self.log_vo = LogVO(cfg.get("log_vo.caminho"), bool(cfg.get("log_vo.mascarar_senhas", True)))
        self.template_email = cfg.raiz / "config" / "templates" / "email_unidade.html"

        self.mailer: Optional[Mailer] = None
        if not dry_run:
            self.mailer = self._criar_mailer()
            if redirecionar_emails:
                self.mailer = RedirecionadorMailer(self.mailer, redirecionar_emails)

    # ===================================================== REFramework: Init
    def kill_all_processes(self) -> None:
        self.wp.fechar()

    def init_all_applications(self) -> None:
        usuario = Config.segredo("WP_USUARIO")
        senha = Config.segredo("WP_SENHA")
        self.wp.iniciar()
        self.wp.login(usuario, senha)

    def close_all_applications(self) -> None:
        self.wp.fechar()

    # ====================================== REFramework: Get Transaction Data
    def get_transaction_data(self, numero: int) -> Optional[TransactionItem]:
        return self.itens[numero] if numero < len(self.itens) else None

    # ======================================= REFramework: Process Transaction
    def process_transaction(self, item: TransactionItem) -> None:
        unidade: Unidade = item.data["unidade"]
        senhas: List[Tuple[str, str]] = item.data["senhas"]
        salvos = item.progresso.setdefault("salvos", [])

        for cadastro in unidade.cadastros:
            if cadastro.post_id in salvos:
                log.info("%s (post %s) já foi salvo em tentativa anterior; pulando.", cadastro.nome, cadastro.post_id)
                continue

            self.wp.abrir_cadastro(cadastro.post_id)

            if self.dry_run:
                for linha, (rotulo, _) in enumerate(senhas):
                    atual = self.wp.ler_senha(linha)
                    log.info("[DRY-RUN] %s - %s: senha atual %s", cadastro.nome, rotulo or "Capela",
                             mascarar(atual) if atual else "(vazia)")
                continue

            for linha, (_, senha) in enumerate(senhas):
                self.wp.preencher_senha(linha, senha)
            self.wp.salvar()

            # Confere no cadastro recarregado que o que ficou gravado é o que foi digitado.
            for linha, (rotulo, senha) in enumerate(senhas):
                gravada = self.wp.ler_senha(linha)
                if gravada != senha:
                    raise RuntimeError(
                        f"{cadastro.nome}: senha de '{rotulo or 'Capela'}' não ficou gravada após salvar."
                    )
            salvos.append(cadastro.post_id)
            log.info("%s (post %s): senhas gravadas e conferidas.", cadastro.nome, cadastro.post_id)

            try:
                self.log_vo.registrar(cadastro.nome, self.data_execucao, senhas)
            except OSError as e:
                aviso = f"Não foi possível gravar no Log_VO ({cadastro.nome}): {e}"
                log.warning(aviso)
                self.avisos.append(aviso)

        if self.dry_run:
            log.info("[DRY-RUN] E-mail de %s não enviado.", unidade.nome)
            return

        if not item.progresso.get("email_enviado"):
            corpo = montar_email_unidade(self.template_email, senhas)
            self.mailer.enviar(unidade.para, self.cfg.get("email.assunto"), corpo, cco=unidade.cco)
            item.progresso["email_enviado"] = True

    def on_transaction_error(self, item: TransactionItem, erro: BaseException) -> None:
        self.wp.screenshot(f"erro_{item.data['unidade'].chave}")

    # =============================================== REFramework: End Process
    def end_process(self, resultado: Resultado) -> None:
        linhas = []
        for item in resultado.itens:
            unidade: Unidade = item.data["unidade"]
            salvos = item.progresso.get("salvos", [])
            if item.status is Status.SUCESSO:
                linhas.append((unidade.nome, "OK", "Senhas gravadas e e-mail enviado." if not self.dry_run else "Dry-run OK."))
                continue
            situacao = "NÃO PROCESSADO" if item.status is Status.NAO_PROCESSADO else "FALHA"
            gravados = [c.nome for c in unidade.cadastros if c.post_id in salvos]
            detalhe = item.erro or "Erro desconhecido."
            if gravados:
                detalhe += f" | Senha nova JÁ GRAVADA em: {', '.join(gravados)}."
                if not item.progresso.get("email_enviado"):
                    detalhe += " A unidade NÃO recebeu o e-mail."
            linhas.append((unidade.nome, situacao, detalhe))

        for u, s, d in linhas:
            log.info("Resumo | %-20s | %-15s | %s", u, s, d)
        if resultado.erro_fatal:
            log.error("Resumo | erro fatal: %s", resultado.erro_fatal)

        if self.dry_run:
            return

        precisa_alertar = not resultado.sucesso_total or self.avisos
        if not precisa_alertar and not self.cfg.get("alertas.enviar_resumo_em_sucesso", False):
            return

        assunto = self.cfg.get("alertas.assunto")
        if not precisa_alertar:
            assunto = "[OK] Velório Online - troca semanal de senhas"
        elif resultado.sucesso_total:
            assunto = "[AVISO] Velório Online - troca semanal de senhas"
        corpo = montar_alerta_ti(linhas, resultado.erro_fatal, self.avisos, self.arquivo_log)
        try:
            self.mailer.enviar(list(self.cfg.get("alertas.destinatarios")), assunto, corpo)
        except Exception as e:  # noqa: BLE001
            log.error("Não foi possível enviar o alerta para a TI: %s", e)

    # ================================================================ helpers
    def _criar_mailer(self) -> Mailer:
        backend = self.cfg.get("email.backend", "smtp")
        remetente = self.cfg.get("email.remetente")
        if backend == "smtp":
            return SmtpMailer(
                host=self.cfg.get("email.smtp.host"),
                porta=self.cfg.get("email.smtp.porta"),
                remetente=remetente,
                senha=Config.segredo("EMAIL_SENHA"),
            )
        if backend == "graph":
            return GraphMailer(
                tenant_id=Config.segredo("GRAPH_TENANT_ID"),
                client_id=Config.segredo("GRAPH_CLIENT_ID"),
                client_secret=Config.segredo("GRAPH_CLIENT_SECRET"),
                remetente=remetente,
            )
        raise ConfigError(f"email.backend inválido: {backend}")
