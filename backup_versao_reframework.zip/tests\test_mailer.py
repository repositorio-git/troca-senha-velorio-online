"""Envio SMTP contra um servidor SMTP local de teste."""

from aiosmtpd.controller import Controller

from velorio.apps.mailer import RedirecionadorMailer, SmtpMailer


class Coletor:
    def __init__(self):
        self.mensagens = []

    async def handle_DATA(self, server, session, envelope):
        self.mensagens.append(envelope)
        return "250 OK"


def test_smtp_com_cco_so_no_envelope():
    coletor = Coletor()
    ctrl = Controller(coletor, hostname="127.0.0.1", port=8025)
    ctrl.start()
    try:
        m = SmtpMailer("127.0.0.1", 8025, "cortex@cortel.com.br", senha="")
        m.enviar(["a@cortel.com.br", "b@cortel.com.br"], "Velório Online", "<p>oi</p>", cco=["ti.logs@cortel.com.br"])
        RedirecionadorMailer(m, "teste@cortel.com.br").enviar(["a@cortel.com.br"], "X", "<p>y</p>", cco=["z@cortel.com.br"])
    finally:
        ctrl.stop()
    env1, env2 = coletor.mensagens
    assert set(env1.rcpt_tos) == {"a@cortel.com.br", "b@cortel.com.br", "ti.logs@cortel.com.br"}
    corpo = env1.content.decode("utf-8", "replace")
    assert "ti.logs@cortel.com.br" not in corpo.split("\r\n\r\n")[0]  # não aparece no cabeçalho
    assert env2.rcpt_tos == ["teste@cortel.com.br"]
