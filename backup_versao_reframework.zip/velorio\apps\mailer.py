"""Envio de e-mail pela conta cortex@cortel.com.br.

Dois backends, escolhidos em config.yaml (email.backend):
- smtp:  smtp.office365.com:587 com usuário e senha (o que o Rocketbot faz hoje).
- graph: Microsoft Graph com app registration (client credentials). Use este se
         o SMTP AUTH for desativado no tenant.
"""

from __future__ import annotations

import logging
import smtplib
from email.message import EmailMessage
from email.utils import formatdate, make_msgid
from typing import List, Optional

import requests

log = logging.getLogger("email")


class Mailer:
    def enviar(self, para: List[str], assunto: str, html: str, cco: Optional[List[str]] = None) -> None:
        raise NotImplementedError


class SmtpMailer(Mailer):
    def __init__(self, host: str, porta: int, remetente: str, senha: str, timeout: int = 60):
        self.host, self.porta = host, int(porta)
        self.remetente, self.senha = remetente, senha
        self.timeout = timeout

    def enviar(self, para, assunto, html, cco=None):
        cco = cco or []
        msg = EmailMessage()
        msg["From"] = self.remetente
        msg["To"] = ", ".join(para)
        msg["Subject"] = assunto
        msg["Date"] = formatdate(localtime=True)
        msg["Message-ID"] = make_msgid(domain=self.remetente.split("@")[-1])
        msg.set_content("Este e-mail precisa de um leitor com suporte a HTML.")
        msg.add_alternative(html, subtype="html")
        # Cópia oculta vai só no envelope, nunca no cabeçalho.
        with smtplib.SMTP(self.host, self.porta, timeout=self.timeout) as smtp:
            smtp.ehlo()
            if smtp.has_extn("starttls"):
                smtp.starttls()
                smtp.ehlo()
            if self.senha:
                smtp.login(self.remetente, self.senha)
            smtp.send_message(msg, from_addr=self.remetente, to_addrs=list(para) + list(cco))
        log.info("E-mail '%s' enviado para %d destinatário(s) (+%d em cópia oculta).", assunto, len(para), len(cco))


class GraphMailer(Mailer):
    def __init__(self, tenant_id: str, client_id: str, client_secret: str, remetente: str, timeout: int = 60):
        self.tenant_id, self.client_id, self.client_secret = tenant_id, client_id, client_secret
        self.remetente = remetente
        self.timeout = timeout

    def _token(self) -> str:
        r = requests.post(
            f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token",
            data={
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "scope": "https://graph.microsoft.com/.default",
            },
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json()["access_token"]

    def enviar(self, para, assunto, html, cco=None):
        def destinatarios(lista):
            return [{"emailAddress": {"address": e}} for e in lista or []]

        r = requests.post(
            f"https://graph.microsoft.com/v1.0/users/{self.remetente}/sendMail",
            headers={"Authorization": f"Bearer {self._token()}"},
            json={
                "message": {
                    "subject": assunto,
                    "body": {"contentType": "HTML", "content": html},
                    "toRecipients": destinatarios(para),
                    "bccRecipients": destinatarios(cco),
                },
                "saveToSentItems": True,
            },
            timeout=self.timeout,
        )
        if r.status_code != 202:
            raise RuntimeError(f"Graph sendMail falhou: HTTP {r.status_code} {r.text[:500]}")
        log.info("E-mail '%s' enviado via Graph para %d destinatário(s).", assunto, len(para))


class RedirecionadorMailer(Mailer):
    """Modo de teste: manda tudo para um endereço só, sem cópia oculta."""

    def __init__(self, interno: Mailer, destino: str):
        self.interno, self.destino = interno, destino

    def enviar(self, para, assunto, html, cco=None):
        aviso = (
            '<div style="background:#fff3cd;padding:12px;font-family:Arial;font-size:13px">'
            f"<b>TESTE</b>: destinatários originais: {', '.join(para)}"
            f"{' | CCO: ' + ', '.join(cco) if cco else ''}</div>"
        )
        self.interno.enviar([self.destino], f"[TESTE] {assunto}", aviso + html, cco=[])
